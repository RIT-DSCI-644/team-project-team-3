import pandas as pd
import collections
import nltk
from nltk.sentiment.vader import SentimentIntensityAnalyzer
import csv
import math
import random
import kivy
from kivy.app import App
from kivy.config import Config
from kivy.lang import Builder
Config.set('graphics', 'resizable', '0') #0 being off 1 being on as in true/false
Config.set('graphics', 'width', '750')
Config.set('graphics', 'height', '600')
from kivy.uix.screenmanager import ScreenManager, Screen
from kivy.uix.button import Button
from barcode.writer import ImageWriter
from kivy.factory import Factory
from kivy.properties import BooleanProperty, ObjectProperty, StringProperty
from kivy.core.window import Window
from kivy.uix.widget import Widget
from kivy.graphics import Rectangle, Color
from kivy.properties import ListProperty


class MainPage(Screen):
    def __init__(self, **kwargs):
        super(MainPage, self).__init__(**kwargs)

class ScreenOneScreen(Screen):
    def __init__(self, **kwargs):
        super(ScreenOneScreen, self).__init__(**kwargs)

class ScreenTwoScreen(Screen):

    def __init__(self, **kwargs):
        super(ScreenTwoScreen, self).__init__(**kwargs)

class ScreenThreeScreen(Screen):

    def __init__(self, **kwargs):
        super(ScreenThreeScreen, self).__init__(**kwargs)


class MouseOver(Widget):
 
    def __init__(self, **kwargs):
        Window.bind(mouse_pos=self._mouse_move)
        self.hovering = BooleanProperty(False)
        self.poi = ObjectProperty(None)
        self.register_event_type('on_hover')
        self.register_event_type('on_exit')
        super(MouseOver, self).__init__(**kwargs)
 
    def _mouse_move(self, *args):
        if not self.get_root_window():
            return
        is_collide = self.collide_point(*self.to_widget(*args[1]))
        if self.hovering == is_collide:
            return
        self.poi = args[1]
        self.hovering = is_collide
        self.dispatch('on_hover' if is_collide else 'on_exit')
 
    def on_hover(self):
        """Mouse over"""
 
    def on_exit(self):
        """Mouse leaves"""
 
 
Factory.register('MouseOver', MouseOver)

class HoverButton(Button, MouseOver):
    """ Base class for Prev and Next Image Buttons"""
    hoverBtnBkgrd = ListProperty((.89,.41,.08,1)) #orange
 
    def on_hover(self):
        self.hoverBtnBkgrd = (.36,.20,.38,1) #purple
 
    def on_exit(self):
        self.hoverBtnBkgrd = (.89,.41,.08,1) #orange

class ScreenManagement(ScreenManager):
    pass

GUIs = Builder.load_file("Project.kv")

class ProjectApp(App):

    def build(self): #Return Root Widget
        return GUIs


if __name__ == '__main__':
    ProjectApp().run()

def importCSV(self):
    nltk.downloader.download('vader_lexicon')
    trump=pd.read_csv(r"trump_raw.csv")
    clinton=pd.read_csv(r"clinton_raw.csv")
    congress=pd.read_csv(r"congress_raw.csv")