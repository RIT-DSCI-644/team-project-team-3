To run, just download the entire folder and run the _644Project.py file. 

Python installs needed (if you don't have them already):
pip install kivy
pip install pandas
pip install nltk